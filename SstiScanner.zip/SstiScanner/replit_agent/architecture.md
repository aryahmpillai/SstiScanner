# Architecture Overview

## 1. Overview

The SSTI Vulnerability Scanner is a Python-based command-line tool designed to detect Server-Side Template Injection (SSTI) vulnerabilities in web applications. It systematically tests web application parameters by injecting template expressions and analyzing responses to identify potential vulnerabilities across multiple template engines (Jinja2, Twig, Pebble, Velocity, FreeMarker, Mako, and ERB).

The application follows a modular design with clear separation of concerns between core scanning functionality, payload generation, response analysis, and reporting components.

## 2. System Architecture

The system follows a command-line application architecture with the following layers:

1. **Entry Point**: `main.py` handles command-line argument parsing and orchestrates the scanning process.
2. **Core Functionality**: 
   - `scanner.py` contains the main scanning logic
   - `payloads.py` generates test payloads for various template engines
   - `detector.py` analyzes responses to identify vulnerabilities
3. **Output/Reporting**: `reporter.py` formats and presents scan results
4. **Utilities**: `utils.py` provides helper functions used across modules

### Key Design Patterns

- **Command Pattern**: The main application uses command-line arguments to configure scanner behavior
- **Strategy Pattern**: Different scanning approaches based on template engines
- **Builder Pattern**: Used for constructing complex HTTP requests with different parameters and payloads

## 3. Key Components

### 3.1 Scanner Module (`scanner.py`)

The core scanning engine responsible for:
- Analyzing target URLs to identify parameters
- Injecting payloads into parameters
- Making HTTP requests with injected payloads
- Coordinating with the response analyzer to detect vulnerabilities

The `Scanner` class orchestrates the entire scanning process, while the `ScanResult` class encapsulates individual vulnerability findings.

### 3.2 Payload Generator (`payloads.py`)

Responsible for generating test payloads for different template engines:
- Contains engine-specific injection patterns
- Provides a unified interface to retrieve payloads by template engine type
- Implements various attack vectors for each supported template engine

### 3.3 Response Analyzer (`detector.py`)

Analyzes HTTP responses to detect successful SSTI injections:
- Uses pattern matching to identify signs of successful template execution
- Applies heuristics to determine confidence levels
- Extracts evidence of vulnerabilities from responses

### 3.4 Reporter (`reporter.py`)

Handles formatting and output of scan results:
- Provides colored console output (using colorama if available)
- Exports results to JSON format
- Formats results for human readability

### 3.5 Utilities (`utils.py`)

Contains helper functions used across the application:
- HTML parsing to extract form fields
- Parameter normalization
- URL manipulation

## 4. Data Flow

1. **Input Processing**:
   - Command-line arguments are parsed in `main.py`
   - URL and parameters to test are identified

2. **Scanning Process**:
   - For each parameter, test payloads are generated
   - HTTP requests are made with injected payloads
   - Responses are analyzed for signs of successful injection

3. **Result Handling**:
   - Vulnerabilities are collected and aggregated
   - Results are formatted and displayed to the user
   - Optionally exported to a file

## 5. External Dependencies

The application relies on the following external libraries:

- **requests**: For making HTTP requests to target applications
- **colorama**: For color-coded console output
- **flask** and **flask-sqlalchemy**: For development/testing purposes
- **gunicorn**: For deployment as a web service
- **psycopg2-binary**: For PostgreSQL database functionality (likely for future storage of scan results)

## 6. Deployment Strategy

The application is designed to be deployed in multiple ways:

### 6.1 Command-Line Tool

Primary usage is as a command-line tool that can be run directly on a system with Python 3.11+ installed.

### 6.2 Web Service

The application can also be deployed as a web service using Gunicorn:
- Configuration in `.replit` indicates deployment as an auto-scaling service
- Gunicorn is configured to serve the application on port 5000
- This enables the tool to be used in a web-based interface or as an API

### 6.3 Containerization

While not explicitly implemented in the current codebase, the project structure and dependencies would support containerization:
- The Python dependencies are clearly defined in `pyproject.toml`
- External requirements like PostgreSQL are identified

## 7. Future Extension Points

The architecture allows for several extension points:

1. **Additional Template Engines**: The modular design of the payload generator makes it easy to add support for new template engines

2. **Enhanced Detection Methods**: The response analyzer can be extended with more sophisticated detection algorithms

3. **Persistent Storage**: The PostgreSQL dependency suggests plans for storing scan results or vulnerability findings

4. **Authentication Support**: The scanner could be enhanced to support authenticated scanning of protected applications

5. **API Integration**: The web service deployment option could be expanded to provide a full REST API for integration with other security tools